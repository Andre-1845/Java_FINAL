package com.andrino.cad_pessoa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadPessoaApplicationTests {

	@Test
	void contextLoads() {
	}

}
