package com.andrino.cad_pessoa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadPessoaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadPessoaApplication.class, args);
	}

}
